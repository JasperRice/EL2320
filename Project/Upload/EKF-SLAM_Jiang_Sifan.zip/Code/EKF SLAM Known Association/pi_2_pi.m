function output = pi_2_pi(input)
output = mod(input + pi, 2 * pi) - pi;
end